from django.contrib import admin
from .models import book 
# Register your models here.
from .models import author,Address,country
class BookAdmin(admin.ModelAdmin):
    list_display = ('title', 'author', 'rating', 'isbestselling')
    search_fields = ('title', 'author')
    prepopulated_fields = {'slug': ('title',)}
    list_filter = ('isbestselling', 'rating')
admin.site.register(book, BookAdmin)

class AuthorAdmin(admin.ModelAdmin):
    list_display = ('name',)
    search_fields = ('name',)
    prepopulated_fields = {'slug': ('name',)}

  # Assuming you have an Author model registered similarly

admin.site.register(author)
admin.site.register(Address)
admin.site.register(country)