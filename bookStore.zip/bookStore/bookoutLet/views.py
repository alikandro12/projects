from django.shortcuts import render, get_object_or_404
from .models import book
from django.db.models import Avg

def index(request):
    books = book.objects.all().order_by('title')
    num = book.objects.count()
    avgR = book.objects.aggregate(Avg('rating'))
    return render(request, 'bookoutlet/index.html', {'books': books, 'num': num, 'avgR': avgR})

def book_detail(request, slug):
    book_instance = get_object_or_404(book, slug=slug)
    return render(request, 'bookoutlet/book.html', {'book': book_instance})
