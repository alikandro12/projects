from django.db import models
from django.core.validators import MinValueValidator, MaxValueValidator
from django.urls import reverse
from django.utils.text import slugify

# Create your models here.
class book(models.Model):
    title = models.CharField(max_length=200)
    author = models.ForeignKey('author', on_delete=models.CASCADE, null=True, blank=True)
    rating = models.IntegerField(validators=[MinValueValidator(1), MaxValueValidator(5)])
    isbestselling = models.BooleanField(default=False)
    slug = models.SlugField(default="", null=False, db_index=True, blank=True)
    published_country = models.ManyToManyField("country", verbose_name=("Published Countries"))
    def get_absolute_url(self):
        return reverse("book_detail", args=[self.slug])

    def __str__(self):
        return f"{self.title}  (Rating: {self.rating})"


class Address(models.Model):
    street = models.CharField(max_length=200)
    city = models.CharField(max_length=100)
    state = models.CharField(max_length=100)
    zip_code = models.CharField(max_length=20)
    def __str__(self):
        return f"{self.street}, {self.city}, {self.state} {self.zip_code}"

    class Meta:
        verbose_name = "Address entity"
        verbose_name_plural = "Addresses entities"    
class author(models.Model):
    name = models.CharField(max_length=100)
    bio = models.TextField(null=True, blank=True)
    slug = models.SlugField(default="", null=False, db_index=True, blank=True)
    #favorite_book = models.OneToOneField("book", verbose_name=_("Favorite Book"), on_delete=models.CASCADE, related_name='favorite_author', blank=True)
    address = models.OneToOneField(Address, on_delete=models.CASCADE, null=True, blank=True)

    def __str__(self):
        return self.name

    def get_absolute_url(self):
        return reverse("author_detail", args=[self.slug])
class country(models.Model):
    name = models.CharField(max_length=100)
    code = models.CharField(max_length=10)

    def __str__(self):
        return self.name
