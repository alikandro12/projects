from django.http import HttpResponse, HttpResponseNotFound

def jan(request):
    return HttpResponse("January challenge")

def febe(request):
    return HttpResponse("February challenge!")
def monthly(request, month):
    ch=None
    if month == "jan":
        return HttpResponse(jan())
    elif month == "febe":
        return HttpResponse(febe())
    else:
        return HttpResponseNotFound("Sorry, I don't know that month.")#from path("<month>"... 