from django.db import models

# Create your models here.
class Review(models.Model):
    username = models.CharField(max_length=10)
    review = models.TextField(max_length=100)
    rating = models.IntegerField(choices=[(i, i) for i in range(1, 6)])
