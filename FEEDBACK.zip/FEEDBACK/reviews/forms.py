from django import forms
from .models import Review
#class ReviewForm(forms.Form):
 #  review = forms.CharField(label="Your Review", max_length=100,widget=forms.Textarea,error_messages={'required': 'Please enter your review.'})
  #  rating = forms.IntegerField(label="Rating", min_value=1, max_value=5,error_messages={'required': 'Please enter a rating between 1 and 5.'})

class ReviewForm(forms.ModelForm):
    class Meta:
        model = Review
        fields = "__all__"
        labels = {
            'username': 'Your Name',
            'review': 'Your Review',
            'rating': 'Rating',
        }
        error_messages = {
            'username': {
                'required': 'Please enter your name.',
            },
            'review': {
                'required': 'Please enter your review.',
            },
            'rating': {
                'required': 'Please enter a rating between 1 and 5.',
            },
        }
