from django.shortcuts import render
from django.http import HttpResponseRedirect
from .forms import ReviewForm
from .models import Review
from django.views.generic import View
from django.views.generic.base import TemplateView
from django.views.generic import ListView,DetailView
from django.views.generic.edit import FormView
from django.views.generic.edit import CreateView

# Create your views here.
class ReviewListView(CreateView):
  model = Review

  form_class = ReviewForm
  template_name = 'review.html'
  success_url = '/thank-you/'

  

#def review_list(request):
  # form = ReviewForm()
   #if request.method == "POST":
    #   form = ReviewForm(request.POST)
     #  if form.is_valid():
           #review = Review(
           #    username=form.cleaned_data['username'],
           #    review=form.cleaned_data['review'],
           #    rating=form.cleaned_data['rating']
           #) review.save()
           # we now have model form
      #     form.save()
       #    return HttpResponseRedirect("/thank-you/")

      # else:
         #  form = ReviewForm()

   #return render(request, 'review.html', {'form': form})
class ThankYouView(TemplateView):
    template_name = 'thank-you.html'
    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['message'] = "Thank you for your feedback!"
        return context
class ReviewListViews(ListView):
    template_name = 'review-list.html'
    model = Review
    context_object_name = 'reviews'
   # def get_queryset(self):
       # base_query=super().get_queryset()
       # base_query = base_query.filter(rating__gte=4)
       # return base_query

class SingleReviewView(DetailView):
    template_name = 'single-review.html'
    model = Review
    context_object_name = 'review'
    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        load_review=self.object
        request=self.request
        favorite_id=request.session.get('favorite_review')
        context['favorite_review'] = favorite_id==str(load_review.id)
        return context
class FavoriteReviewView(View):
    def post(self, request, *args, **kwargs):
        review_id = request.POST.get("review_id")
        username = request.POST.get("username")
        review = request.POST.get("review")
        rating = request.POST.get("rating")
        favorite = request.POST.get("favorite")
    
        request.session['favorite_review'] = review_id
        # Handle the favorite action (e.g., save to database)
        # ...

        return HttpResponseRedirect("/reviews/" + review_id)