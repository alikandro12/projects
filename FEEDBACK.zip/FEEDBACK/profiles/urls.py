# profiles/urls.py
from django.urls import path
from . import views

urlpatterns = [
    path("", views.CreateProfileView.as_view(), name="create_profile"),  # URL is /profiles/
    path("list/", views.UserProfileListView.as_view(), name="user_profile_list"),
]
