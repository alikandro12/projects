from django.shortcuts import render, redirect
from django.views import View
from .forms import ProfilePictureForm
from .models import UserProfile
from django.views.generic.edit  import CreateView
from django.views.generic import ListView
class CreateProfileView(CreateView):
    template_name = "profiles/create-profile.html"
    form_class = ProfilePictureForm
    success_url = "/profiles/"
    model = UserProfile

class UserProfileListView(ListView):
    model = UserProfile
    template_name = "profiles/user-profile.html"
    context_object_name = "profiles"
