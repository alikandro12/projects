from datetime import datetime
from django.shortcuts import render
all_posts= [
    {
        'title': 'Cute Animal',
        'slug': 'cute-animal',
        'image': 'blog/images/you.png',
        'content': 'A tiger is a large, carnivorous mammal, and the largest member of the cat family, Panthera tigris. They are known for their distinctive orange and black striped coat, which provides camouflage for hunting. Tigers are apex predators, meaning they are at the top of their food chain and have no natural predators. They are found in Asia and southern Russi',
        'date': datetime(2023, 3, 15)
    },
    {
        'title': 'Another Post',
        'slug': 'another-post',
        'image': 'blog/images/wolf.png',
        'content': 'A wolf is a large, wild mammal in the dog family (Canidae), known for its social behavior and hunting in packs. There are several wolf species, with the gray wolf (Canis lupus) being the most well-known. Wolves are found in various regions of the Northern Hemisphere, including North America, Europe, and Asia. ',
        'date': datetime(2023, 3, 16)
    },
    {
        'title': 'Yet Another Post',
        'slug': 'yet-another-post',
        'image': 'blog/images/panda.png',
        'content': 'A panda is a large, black and white bear native to the bamboo forests of central China. They are known for their distinctive coloration and their dependence on bamboo for food. Giant pandas are classified as vulnerable by the IUCN due to habitat loss and other threats. ',
        'date': datetime(2023, 3, 17)
    },
    {
        'title': 'cool-Animal',
        'slug': 'cool-animal',
        'image': 'blog/images/nig.png',
        'content': 'A fox is a small, dog-like mammal known for its pointed ears, long snout, and bushy tail. They are part of the Canidae family and are often associated with cunning and trickery in folklore. There are many different types of foxes, including the red fox, the Arctic fox, and the gray fox. Red foxes, in particular, have a wide distribution and are found in both the Old and New Worlds. ',
        'date': datetime(2023, 3, 15)
    }
]
def get_date(post):
    return post.get('date')
def home(request):
    sorted_posts = sorted(all_posts, key=get_date)
    return render(request, "blog/index.html", {'posts': sorted_posts})
def posts(request):
     return render(request, "blog/allPosts.html", {'allposts': all_posts})
def postdetails(request,slug):
    post = next(post for post in all_posts if post['slug'] == slug)
    return render(request, "blog/postDetails.html", {'postdetail': post})
